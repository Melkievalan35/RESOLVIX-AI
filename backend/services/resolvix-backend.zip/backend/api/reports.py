"""
Report generation endpoints. Delegates file generation and querying to
services/report_service.py; this router only handles HTTP concerns.
"""
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from core.security import require_roles
from database.connection import get_db
from database.models import User, UserRole
from database.schemas import ReportOut, ReportRequest
from services import report_service

router = APIRouter(prefix="/reports", tags=["Reports"])


@router.post("/generate", response_model=ReportOut)
def generate_report(
    payload: ReportRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.AGENT, UserRole.ADMIN)),
):
    report = report_service.create_report_request(
        db, current_user.id, payload.report_type, payload.date_from, payload.date_to,
    )
    background_tasks.add_task(
        report_service.generate_report_file,
        report.id, payload.report_type, payload.date_from, payload.date_to,
    )
    return report


@router.get("/", response_model=list[ReportOut])
def list_reports(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.AGENT, UserRole.ADMIN)),
):
    return report_service.list_reports(db, current_user)


@router.get("/{report_id}", response_model=ReportOut)
def get_report(
    report_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.AGENT, UserRole.ADMIN)),
):
    report = report_service.get_report(db, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@router.get("/{report_id}/download")
def download_report(
    report_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.AGENT, UserRole.ADMIN)),
):
    report = report_service.get_report(db, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if report.status != "ready" or not report.file_path:
        raise HTTPException(status_code=409, detail=f"Report is not ready (status={report.status})")

    return FileResponse(
        path=report.file_path,
        filename=f"resolvix_report_{report.report_type}_{report_id}.csv",
        media_type="text/csv",
    )
