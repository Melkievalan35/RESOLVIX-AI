"""
Complaint lifecycle endpoints. Thin HTTP layer over services/complaint_service.py
and services/workflow_service.py, which own the actual business logic.
"""
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy.orm import Session

from core.security import get_current_user, require_roles
from database.connection import get_db
from database.models import ComplaintStatus, User, UserRole
from database.schemas import (
    AuditLogOut, ComplaintCreate, ComplaintOut, ComplaintUpdate,
    EvidenceOut, PaginatedComplaints,
)
from services import complaint_service, workflow_service

router = APIRouter(prefix="/complaints", tags=["Complaints"])


@router.post("/", response_model=ComplaintOut, status_code=status.HTTP_201_CREATED)
def create_complaint(
    payload: ComplaintCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return complaint_service.create_complaint(
        db, current_user.id, payload.title, payload.description, payload.category
    )


@router.get("/", response_model=PaginatedComplaints)
def list_complaints(
    status_filter: Optional[ComplaintStatus] = Query(None, alias="status"),
    category: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    total, items = complaint_service.list_complaints(
        db, current_user, status_filter=status_filter, category=category,
        page=page, page_size=page_size,
    )
    return PaginatedComplaints(total=total, page=page, page_size=page_size, items=items)


@router.get("/{complaint_id}", response_model=ComplaintOut)
def get_complaint(
    complaint_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        return complaint_service.get_complaint(db, complaint_id, current_user)
    except complaint_service.NotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except complaint_service.NotAuthorizedError as e:
        raise HTTPException(status_code=403, detail=str(e))


@router.put("/{complaint_id}", response_model=ComplaintOut)
def update_complaint(
    complaint_id: str,
    payload: ComplaintUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.AGENT, UserRole.ADMIN)),
):
    try:
        return complaint_service.update_complaint(
            db, complaint_id, current_user,
            status=payload.status, priority=payload.priority,
            assigned_agent_id=payload.assigned_agent_id,
            resolution_notes=payload.resolution_notes,
        )
    except complaint_service.NotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except workflow_service.InvalidTransitionError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{complaint_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_complaint(
    complaint_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN)),
):
    try:
        complaint_service.delete_complaint(db, complaint_id)
    except complaint_service.NotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return None


@router.post("/{complaint_id}/assign", response_model=ComplaintOut)
def assign_complaint(
    complaint_id: str,
    agent_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN)),
):
    try:
        return complaint_service.assign_complaint(db, complaint_id, agent_id, current_user)
    except complaint_service.NotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{complaint_id}/auto-assign", response_model=ComplaintOut)
def auto_assign_complaint(
    complaint_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN)),
):
    """Assign the complaint to whichever active agent currently has the lightest load."""
    try:
        complaint = complaint_service.get_complaint(db, complaint_id, current_user)
    except complaint_service.NotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

    agent = workflow_service.auto_assign_agent(db, complaint)
    if not agent:
        raise HTTPException(status_code=409, detail="No active agents available")
    return complaint


@router.post("/{complaint_id}/evidence", response_model=EvidenceOut, status_code=status.HTTP_201_CREATED)
def upload_evidence(
    complaint_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        return complaint_service.add_evidence(db, complaint_id, file, current_user)
    except complaint_service.NotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except complaint_service.NotAuthorizedError as e:
        raise HTTPException(status_code=403, detail=str(e))


@router.get("/{complaint_id}/history", response_model=list[AuditLogOut])
def get_complaint_history(
    complaint_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        return complaint_service.get_history(db, complaint_id, current_user)
    except complaint_service.NotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except complaint_service.NotAuthorizedError as e:
        raise HTTPException(status_code=403, detail=str(e))
