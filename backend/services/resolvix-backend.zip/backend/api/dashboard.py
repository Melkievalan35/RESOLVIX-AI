"""
Dashboard and analytics endpoints for the admin panel.
Delegates aggregation logic to services/report_service.py.
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from core.security import require_roles
from database.connection import get_db
from database.models import Complaint, User, UserRole
from database.schemas import DashboardSummary
from services import report_service

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/summary", response_model=DashboardSummary)
def get_summary(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.AGENT, UserRole.ADMIN)),
):
    return report_service.dashboard_summary(db)


@router.get("/trends")
def get_trends(
    days: int = Query(14, ge=1, le=90),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.AGENT, UserRole.ADMIN)),
):
    return {"days": days, "data": report_service.daily_trends(db, days=days)}


@router.get("/fraud-analytics")
def get_fraud_analytics(
    threshold: float = Query(0.5, ge=0.0, le=1.0),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN)),
):
    flagged = (
        db.query(Complaint)
        .filter(Complaint.fraud_score >= threshold)
        .order_by(Complaint.fraud_score.desc())
        .limit(100)
        .all()
    )
    return {
        "threshold": threshold,
        "flagged_count": len(flagged),
        "complaints": [
            {
                "id": c.id,
                "title": c.title,
                "fraud_score": c.fraud_score,
                "status": c.status.value,
                "created_at": c.created_at,
            }
            for c in flagged
        ],
    }


@router.get("/agent-performance")
def get_agent_performance(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN)),
):
    return {"agents": report_service.agent_performance(db)}
