"""
Pydantic schemas shared across API routers.
"""
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, EmailStr, Field

from database.models import ComplaintPriority, ComplaintStatus, NotificationType, UserRole


# ---------- Auth / Users ----------

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=8)
    phone: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    role: UserRole
    is_active: bool
    phone: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------- Complaints ----------

class ComplaintCreate(BaseModel):
    title: str
    description: str
    category: Optional[str] = None


class ComplaintUpdate(BaseModel):
    status: Optional[ComplaintStatus] = None
    priority: Optional[ComplaintPriority] = None
    assigned_agent_id: Optional[str] = None
    resolution_notes: Optional[str] = None


class ComplaintOut(BaseModel):
    id: str
    customer_id: str
    assigned_agent_id: Optional[str]
    title: str
    description: str
    category: Optional[str]
    status: ComplaintStatus
    priority: ComplaintPriority
    fraud_score: float
    confidence_score: float
    sentiment_score: Optional[float]
    ai_summary: Optional[str]
    resolution_notes: Optional[str]
    created_at: datetime
    updated_at: datetime
    resolved_at: Optional[datetime]

    class Config:
        from_attributes = True


class EvidenceOut(BaseModel):
    id: str
    complaint_id: str
    file_path: str
    file_type: str
    uploaded_at: datetime

    class Config:
        from_attributes = True


class AuditLogOut(BaseModel):
    id: str
    action: str
    details: Optional[str]
    actor_id: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


class PaginatedComplaints(BaseModel):
    total: int
    page: int
    page_size: int
    items: List[ComplaintOut]


# ---------- Dashboard ----------

class StatusCount(BaseModel):
    status: str
    count: int


class DashboardSummary(BaseModel):
    total_complaints: int
    open_complaints: int
    resolved_complaints: int
    escalated_complaints: int
    avg_resolution_hours: Optional[float]
    status_breakdown: List[StatusCount]
    high_fraud_count: int


# ---------- Notifications ----------

class NotificationOut(BaseModel):
    id: str
    message: str
    type: NotificationType
    is_read: bool
    related_complaint_id: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Reports ----------

class ReportRequest(BaseModel):
    report_type: str = Field(description="summary | fraud | agent_performance")
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None


class ReportOut(BaseModel):
    id: str
    report_type: str
    status: str
    file_path: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True
